const socket = io('http://localhost:8000');

const form = document.getElementById('formid'); // html ke form ko form iod ke help se access kiye hai
const messageInput = document.getElementById('messageinp'); // html input tag ko input id ke help se access kiye hai
const messageContainer = document.querySelector(".container"); // html container ko access kiye hai

// const append = (message, position)=>{
//     const messageElement = document.createElement('div')
//     messageElement.innerText = message;
//     messageElement.classList.add('message');
//     messageElement.classList.add(position);
//     messageContainer.append(messageElement);

// }

const name = prompt("enter your name"); // for popup message
socket.emit('new-users', name) // sab ko message aaye ga new user with name join ka 

// socket.on('user-joined', name => {
//     append(`${name} joined the chat`,'right' )

// })
